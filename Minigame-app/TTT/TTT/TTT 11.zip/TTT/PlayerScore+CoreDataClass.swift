//
//  PlayerScore+CoreDataClass.swift
//  TTT
//
//  Created by Feliciano Medina on 2/28/25.
//
//

import Foundation
import CoreData

@objc(PlayerScore)
public class PlayerScore: NSManagedObject {

}
