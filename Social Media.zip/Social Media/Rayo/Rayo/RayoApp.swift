//
//  RayoApp.swift
//  Rayo
//
//  Created by Feliciano Medina on 9/11/25.
//

import SwiftUI

@main
struct RayoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
